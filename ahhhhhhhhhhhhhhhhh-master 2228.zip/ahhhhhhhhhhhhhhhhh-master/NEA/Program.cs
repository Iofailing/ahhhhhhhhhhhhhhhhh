using System;
using System.Collections.Generic;
using System.Threading;
using static System.Console;
using System.Linq;

namespace NEA
{
    class Program
    {
        public List<Basic_h_items> Bag = new List<Basic_h_items>();
        //introduction to the game
        public void intro()
        {
            Print("Hello, welcome to 'A game'\nPlease enter 'Start' to start the game");
            string userin1 = ReadLine();
            Clear();

            string welcome = "I hope you have fun playing the game!!!";

            if (userin1.ToLower() == "start")
            {
                Print(welcome);
                ReadLine();
                Clear();
            }
            else
            {
                Print("Are you sure you wouldn't like to play the game. If you would like to, please enter 'Start'");
                string userin2 = ReadLine();
                if (userin2.ToLower() == "start")
                {
                    Print(welcome);
                    ReadLine();
                    Clear();
                }
                else
                {
                    Print("That's a shame, goodbye");
                    ReadLine();
                    Clear();
                    Environment.Exit(0);
                }
            }
        }

        //tutorial of how to play/function the basics game
        public void tutorial()
        {
            Print("You open your eyes and look around.\nYou see a huge clearing surrounded by giant pine trees that look to be extremly old.\nYou see that you have but a simple bag on your person.\nYou look down and see your face reflected in the water.\n'Who am i?' you think to yourself.");
            ReadLine();
            Clear();
            Print("Would you like a tutorial?\nType 'yes' if you would like a tutorial and 'no' if you would not like a tutorial.");
            string userin3 = ReadLine();
            Clear();

            string Tutorial_Basics = "To move, type 'up', 'down', 'left', or 'right'.\nIf you come across an enemy, you will have set choices to pick from.\nTo pick up an item type 'pick up item' or 'add to inventory'\nTyping 'pick up item' will automatically add the item to your inventory.";

            if (userin3.ToLower() == "yes")
            {
                Print(Tutorial_Basics);
                ReadLine();
                Clear();
            }
            else
            {
                Print("Are you sure you wouldn't like a tutorial?");
                string userin4 = ReadLine();
                if (userin4.ToLower() == "yes")
                {
                    Print("Alright; if you're sure then");
                    ReadLine();
                    Clear();
                }
                else
                {
                    Print(Tutorial_Basics);
                    ReadLine();
                }
            }
            Clear();
        }
        //a method for choosing to collect a random dropped item + money
        public void Collection()
        {
            Basic_h_items BasicPotion = new Basic_h_items("Basic Potion", 5, 1);
            Basic_h_items Mushroom = new Basic_h_items("Mushroom", 20, 3);
            Basic_h_items GoldenApple = new Basic_h_items("Golden Apple", 15, 2);
            Basic_h_items SuspiciousBile = new Basic_h_items("Suspicious Bile", 30, 3);
            Basic_h_items GlowingMoss = new Basic_h_items("Glowing Moss", 18, 3);
            Basic_h_items BleedingFairyHelmet = new Basic_h_items("Bleeding Fairy Helmet Mushroom", 50, 5);
            Basic_h_items EasternJackOLanternMushroom = new Basic_h_items("Eastern Jack O Lantern Mushroom", 35, 4);

            Basic_h_items[] DroppedItems = new Basic_h_items[] { BasicPotion, Mushroom, GoldenApple, SuspiciousBile, GlowingMoss, BleedingFairyHelmet, EasternJackOLanternMushroom };

            int Plang = 1;
            Random drop = new Random();


            int CollectItems = drop.Next(0, DroppedItems.Length);
            int numcur = drop.Next(1, 31);
            int money = numcur * Plang;
            Print("The item " + DroppedItems[CollectItems].Name + " has been droppped.\nWould you like to pick it up?");
            string userin = ReadLine();
            Clear();

            if (userin.ToLower() == "pick up item" || userin.ToLower() == "add to inventory")
            {
                Bag.Add(DroppedItems[CollectItems]);
                Print("Your money counter is now: " + money + " plang\n" + "You also have " + DroppedItems[CollectItems].Name + " in your inventory");
            }
            else
            {
                Print("It doesn't seem wise to not add this to your inventory\nDo you want to add this to your inventory?");
                string userin1 = ReadLine();
                if (userin1.ToLower() == "yes")
                {
                    Print("'Wise decision' an eerie vice whispers to you");
                    Bag.Add(DroppedItems[CollectItems]);
                    Print("You now have: " + money + "plang");
                }
                else
                {
                    Print("'Not the wisest of decisions you've made today' you think to yourself");
                }
            }
        }


        //merge sort to unlock npc dialogue
        public void MergeSort(int[] array)
        {
            if (array.Length > 1)
            {
                int mid = array.Length / 2;
                int[] left = new int[mid];
                int[] right = new int[array.Length - mid];

                // Copy elements to left and right arrays
                for (int i = 0; i < mid; i++)
                {
                    left[i] = array[i];
                }
                for (int i = mid; i < array.Length; i++)
                {
                    right[i - mid] = array[i];
                }

                // Recursively sort left and right arrays
                MergeSort(left);
                MergeSort(right);

                // Merge sorted left and right arrays back into original array
                int leftIndex = 0, rightIndex = 0, arrayIndex = 0;
                while (leftIndex < left.Length && rightIndex < right.Length)
                {
                    if (left[leftIndex] < right[rightIndex])
                    {
                        array[arrayIndex] = left[leftIndex];
                        leftIndex++;
                    }
                    else
                    {
                        array[arrayIndex] = right[rightIndex];
                        rightIndex++;
                    }
                    arrayIndex++;
                }

                while (leftIndex < left.Length)
                {
                    array[arrayIndex] = left[leftIndex];
                    leftIndex++;
                    arrayIndex++;
                }

                while (rightIndex < right.Length)
                {
                    array[arrayIndex] = right[rightIndex];
                    rightIndex++;
                    arrayIndex++;
                }
            }
            Console.WriteLine("Now that you have made it to Eplabra, a quick test of number recognition is required. Only those who can count are allowed into the city after all");
            Random num = new Random();
            int x = 5;
            int[] NumArray = new int[5];
            for (int i = 0; i < x; i++)
            {
                NumArray[i] = num.Next(0, 100);
                Console.WriteLine("This is number {0}: {1} ", i, NumArray[i]);
            }

            Console.WriteLine("Could you please sort the numbers in order from smallest to largest");
            MergeSort(NumArray);
            for (int i = 0; i < x; i++)
            {
                int z = int.Parse(Console.ReadLine());
                if (z == NumArray[i])
                {
                    Console.WriteLine("Well done. This is number {0}: {1} ", i, NumArray[i]);
                }
                else
                {
                    Console.WriteLine("That is not the correct input");
                    Console.WriteLine("This is number {0}: {1} ", i, NumArray[i]);
                }
            }

            Console.WriteLine("Remember these numbers, they may come in handy\nA man comes up to you\nHe seems to want to say something\nPerhaps he requires a set of numbers...");
            for (int q = 0; q < 5; q++)
            {
                int h = int.Parse(Console.ReadLine());
                if (h == NumArray[0])
                {
                    Console.WriteLine("Hello young warrior\nI assume you're not from town");
                }
                else if (h == NumArray[1])
                {
                    Console.WriteLine("If you need, there is a shop in town where you can buy wares");
                }
                else if (h == NumArray[2])
                {
                    Console.WriteLine("Don't wander too far from town warrior, you never know what lurks beyond");
                }
                else if (h == NumArray[3])
                {
                    Console.WriteLine("The void seeks all");
                }
                else if (h == NumArray[4])
                {
                    Console.WriteLine("The mist will find you");
                }
                else
                {
                    Console.WriteLine("Sorry, this is not an option\nThe man would like to speak to you player");
                }
            }
        }

        public void FightSequence()
        {
            
            Player player00 = new Player(25, 15, 0, 1);

            Enemy slime = new Enemy("slime", 10, 10, 23, 1);
            Enemy giantBat = new Enemy("giant bat", 15, 15, 9, 1);
            Enemy mossman = new Enemy("moss man", 20, 5, 15, 1);
            Enemy scaler = new Enemy("scaler", 12, 7, 25, 1);
            Enemy creeper = new Enemy("creeper", 14, 12, 17, 1);
            Enemy giantSpider = new Enemy("giant spider", 17, 4, 26, 1);
            Enemy demon = new Enemy("demon", 19, 3, 15, 1);
            Enemy crawler = new Enemy("crawler", 13, 5, 10, 1);

            Enemy[] EnemyList = new Enemy[] { slime, giantBat, mossman, scaler, creeper, giantSpider, demon, crawler };
            Random fight = new Random();

            string[] directions = new string[4] { "up", "down", "left", "right" };


            int mtrmvd = 0;

            for (int i = 0; i < 2; i++)
            {
                Print("Please move");
                string dr = ReadLine();
                Clear();
                Random direct = new Random();
                int drnum = direct.Next(0, directions.Length);

                if (dr.ToLower() == directions[drnum])
                {
                    mtrmvd++;
                    Print("You have moved " + dr + " by " + mtrmvd + " meters.");
                    ReadLine();
                    Clear();
                    int Enemy_Fight = fight.Next(0, EnemyList.Length);
                    //int if_fight = fight.Next(0, 1);

                    WriteLine("Im very sorry, it seems as though a " + EnemyList[Enemy_Fight].Name + " has found you");
                    Print("What would you like to do?\nFight\nRun away");
                    string userin5 = ReadLine();
                    if (userin5.ToLower() == "fight")
                    {
                        Print("You have entered a fight!");
                        Print("You have two options:\nAttack\nDefend\nWhat would you like to do?");
                        string userin6 = ReadLine();
                        Clear();
                        if (userin6.ToLower() == "attack")
                        {
                            WriteLine("You have entered a fight!\nThis is your hp: " + player00.hp + "\nThis is " + EnemyList[Enemy_Fight].Name + "'s hp: " + EnemyList[Enemy_Fight].hp);
                            EnemyList[Enemy_Fight].hp -= player00.attack;
                            if (EnemyList[Enemy_Fight].hp <= 0)
                            {
                                
                                Print("The enemy has been hit!");
                                Print("The " + EnemyList[Enemy_Fight].Name + " has left, it was too stunned to fight anymore");
                                Collection();

                            }
                            else
                            {
                                Print("The enemy has been hit!\nThis is the enemy's hp now: " + EnemyList[Enemy_Fight].hp);
                                Print("The enemy has left, it was too stunned to fight anymore");
                            }
                            player00.hp -= EnemyList[Enemy_Fight].attack;
                            if (player00.hp <= 0)
                            {
                                //End game
                                Print("I'm very sorry but unfortunately, it seems as though you have lost all of your hp. Thank you for playing the game :)");
                                Environment.Exit(0);
                            }

                        }
                        else if (userin6.ToLower() == "defend")
                        {
                            //as this is the start area, 70% of the enemy's attack will be blocked
                            int defenceattack = (int)(EnemyList[Enemy_Fight].attack * 0.3);
                            player00.hp -= defenceattack;
                            Print("You have defended 70% of the enemy's attack\nHere is your current hp: " + player00.hp);
                            Print("Please continue on your way player");
                        }


                    }
                    else if (userin5.ToLower() == "run away")
                    {
                        //chance of escaping 1 in 3
                        Random chance = new Random();
                        int escape = chance.Next(0, 4);
                        if (escape == 1)
                        {
                            Print("You have successfully escaped!");
                        }
                        else
                        {
                            Print("You didn't manage to run away, instead, a mysterious being removed the problem");
                        }
                    }
                    else
                    {
                        Print("I'm sorry, but that is not an option");
                    }
                }
                else
                {
                    Print("Sorry, that is not correct, you'll have to try again");
                    WriteLine("You have moved "+ dr + " by "+ mtrmvd + " meters.");
                    ReadLine();
                    Clear();
                }
            }

            Print("Well done!!\nYou have finally made it out of the forest and to the town of Eplabra!!");
        }

        static void Main(string[] args)
        {
            Program p1 = new Program();
            p1.intro();
            p1.tutorial();
            p1.FightSequence();
            p1.MergeSort(NumArray);




        }

        public static void Print(string input)
        {
            //types out text one letter at a time
            Thread.Sleep(35);
            for (int i = 0; i < input.Length; i++)
            {
                Console.Write(input[i]);
                Thread.Sleep(35);
            }
            Console.WriteLine();
        }


    }
}
